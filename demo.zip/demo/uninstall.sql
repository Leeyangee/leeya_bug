drop table if exists `__PREFIX__addons_demo`;
drop table if exists `__PREFIX__addons_demo_cate`;

