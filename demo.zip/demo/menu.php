<?php

return
    [
        'is_nav' => 1,//1导航栏；0 非导航栏
        'menu' =>
            [
                'href' => 'index',
                'title' => '组件演示',
                'status' => 1,
                'auth_verify' => 1,
                'menu_status' => 1,
                'type' => 1,
                'icon' => 'layui-icon layui-icon-component',
                'menulist' => [
                    ['href' => 'index/index', 'title' => 'list', 'status' => 1, 'menu_status' => 0,],
                    ['href' => 'index/add', 'title' => 'add', 'status' => 1, 'menu_status' => 0,],
                    ['href' => 'index/edit', 'title' => 'edit', 'status' => 1, 'menu_status' => 0,],
                    ['href' => 'index/delete', 'title' => 'delete', 'status' => 1, 'menu_status' => 0,],
                    ['href' => 'index/modify', 'title' => 'modify', 'status' => 1, 'menu_status' => 0,],
                ]
            ]
    ];