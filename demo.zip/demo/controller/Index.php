<?php
/**
 * FunAdmin
 * ============================================================================
 * 版权所有 2017-2028 FunAdmin，并保留所有权利。
 * 网站地址: http://www.FunAdmin.com
 * ----------------------------------------------------------------------------
 * 采用最新Thinkphp6实现
 * ============================================================================
 * Author: yuege
 * Date: 2022/4/11
 * Time: 15:48
 */
namespace addons\demo\controller;

use app\backend\model\MemberGroup;
use fun\addons\Controller;
use addons\demo\backend\model\Demo as DemoModel;
use app\common\model\Member;
use app\common\model\Provinces;
use think\App;
use app\common\annotation\ControllerAnnotation;
use app\common\annotation\NodeAnnotation;
use think\facade\View;

/**
 * @ControllerAnnotation('Index')
 * @package addons\curd\backend\controlLer
 */
class Index extends  Controller
{
    protected  $request ;

    public function __construct(App $app)
    {
        parent::__construct($app);
        $this->request = request();

    }
    public function index()
    {
        return redirect(url('/demo/index'));
    }

}