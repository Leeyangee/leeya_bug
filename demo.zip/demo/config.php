<?php

return array (
  'status' => 
  array (
    'title' => '状态:',
    'type' => 'radio',
    'rule' => 'required',
    'content' => 
    array (
      0 => 'close',
      1 => 'open',
    ),
    'num' => '',
    'value' => '1',
    'msg' => '',
    'tips' => '',
    'ok' => '',
  ),
);