### Github首页地球展示提取
[](https://github.com)
[](https://github.com/ashleyyang0610/threeJS-webGL-globe)

####
原始代码使用 [event-emitter](https://github.com/chilliHsu/Crawl/tree/2798ac01775ed5343adf97eb9d665e719723d4b9/event-emitter),作为事件分发器,需要借助打包工具使用。

![alt](./note/001.png)
