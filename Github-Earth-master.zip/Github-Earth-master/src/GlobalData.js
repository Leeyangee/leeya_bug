const Signal = signals.Signal;

export const bl = {}
export const wl = new THREE.Vector3()

export const _l_pause = new Signal()
export const _l_resume = new Signal()
